from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
import smtplib

class NewUSerForm(UserCreationForm):
    email = forms.EmailField(required=True)
    phone_number = forms.CharField(required=True)
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    address = forms.CharField(required=True)

    class Meta:
        model = User
        fields = ("username", "email", "phone_number", "first_name", "last_name","address", "password1", "password2")

    def save(self,commit=True):
        user = super(NewUSerForm, self).save(commit=False)
        user.email = self.cleaned_data["email"]
        user.phone_number = self.cleaned_data["phone_number"]
        user.first_name = self.cleaned_data["first_name"]
        user.last_name = self.cleaned_data["last_name"]
        user.address = self.cleaned_data["address"]
        if commit:
            subject = "Sign Up successfull"
            print(user.email)
            txt = f'''Hi {user.first_name.title()} Your account has been created successully. Make sure not to share your password with anyone
Thank You.'''
            message = f''' {subject} \n\n{txt}'''
            server = smtplib.SMTP("smtp.gmail.com",587)
            server.starttls()
            server.login("itsprincenarula@gmail.com","Narula@2001")
            server.sendmail("itsprincenarula@gmail.com",
                            user.email,
                            message
            )
            server.quit()
            user.save()
        return user